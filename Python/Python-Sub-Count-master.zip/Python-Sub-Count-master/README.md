howCode's Python script for counting YouTube subscribers.
========================================================

You can use this code for anything you'd like, no credit etc ... required. It would be nice though!

You can watch the video here: https://www.youtube.com/watch?v=jaxjVqgLEs0

Enjoy!
